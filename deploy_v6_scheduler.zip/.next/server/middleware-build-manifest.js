globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/625541ac10df0301.js",
    "static/chunks/0f85183dcdcd7349.js",
    "static/chunks/4d5d0c700707da65.js",
    "static/chunks/b0ee639149b9e9f3.js",
    "static/chunks/turbopack-0e2a431246234b40.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];