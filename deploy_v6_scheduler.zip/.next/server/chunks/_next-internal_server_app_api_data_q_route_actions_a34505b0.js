module.exports=[21146,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data_q_route_actions_a34505b0.js.map