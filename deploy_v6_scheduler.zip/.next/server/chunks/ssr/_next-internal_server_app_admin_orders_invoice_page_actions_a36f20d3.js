module.exports=[91083,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_orders_invoice_page_actions_a36f20d3.js.map