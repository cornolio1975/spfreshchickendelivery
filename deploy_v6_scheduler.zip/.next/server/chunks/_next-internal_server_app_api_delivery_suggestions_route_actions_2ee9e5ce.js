module.exports=[43999,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_delivery_suggestions_route_actions_2ee9e5ce.js.map