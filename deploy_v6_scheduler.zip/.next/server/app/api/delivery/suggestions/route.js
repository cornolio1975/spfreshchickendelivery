var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/delivery/suggestions/route.js")
R.c("server/chunks/[root-of-the-server]__a50ee6ab._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__6f76c59e._.js")
R.c("server/chunks/_next-internal_server_app_api_delivery_suggestions_route_actions_2ee9e5ce.js")
R.m(26361)
module.exports=R.m(26361).exports
