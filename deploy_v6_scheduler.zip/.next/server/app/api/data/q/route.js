var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/data/q/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__6f76c59e._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_ede77e05._.js")
R.c("server/chunks/_next-internal_server_app_api_data_q_route_actions_a34505b0.js")
R.m(55667)
module.exports=R.m(55667).exports
